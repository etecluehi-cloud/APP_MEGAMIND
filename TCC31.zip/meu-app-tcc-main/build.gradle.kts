buildscript {
    repositories{
        google()
        mavenCentral()
    }
    dependencies {
        classpath("com.android.tools.build:gradle:8.0.0")
        classpath ("com.google.gms:google-services:4.4.0")
    }
}
