package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;


import com.google.firebase.FirebaseException;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthOptions;
import com.google.firebase.auth.PhoneAuthProvider;

import java.util.concurrent.TimeUnit;

public class TelaRecuperarSenhaNumero extends AppCompatActivity
{
    // 1) atributos
    ImageButton btnVoltar;
    TextView lblRecupEmail;
    Button btnRecupNumero;
    EditText txtNumeroCad;
    String codigoVerificacao;
    PhoneAuthProvider.OnVerificationStateChangedCallbacks mCallbacks;
    FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_recuperar_senha_numero);

        // 2) linkando os elementos
        btnRecupNumero = (Button) findViewById(R.id.btnRecupNumero);
        txtNumeroCad = (EditText) findViewById(R.id.txtNumeroCad);
        btnVoltar = (ImageButton) findViewById(R.id.btnVoltar);
        lblRecupEmail = (TextView) findViewById(R.id.lblRecupEmail);
        mAuth = FirebaseAuth.getInstance();

        // Callback do Firebase
        mCallbacks = new PhoneAuthProvider.OnVerificationStateChangedCallbacks()
        {
            @Override
            public void onVerificationCompleted(PhoneAuthCredential credential)
            {
            }

            @Override
            public void onVerificationFailed(FirebaseException e)
            {
                Toast.makeText(getApplicationContext(), "Erro ao eviar SMS", Toast.LENGTH_LONG).show();
            }

            @Override
            public void onCodeSent(String verificationId,
                                   PhoneAuthProvider.ForceResendingToken token)
            {
                codigoVerificacao = verificationId;

                Toast.makeText(getApplicationContext(), "Código enviado por SMS", Toast.LENGTH_LONG).show();
            }
        };


        // Evento button Recuperar por numero
        btnRecupNumero.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                   String numero = "+55" + txtNumeroCad.getText().toString();

                PhoneAuthOptions options =
                        PhoneAuthOptions.newBuilder(mAuth)
                                .setPhoneNumber(numero)
                                .setTimeout(60L, TimeUnit.SECONDS)
                                .setActivity(TelaRecuperarSenhaNumero.this)
                                .setCallbacks(mCallbacks)
                                .build();

                PhoneAuthProvider.verifyPhoneNumber(options);
            }
        });

        // 3) evento do btnVoltar
        btnVoltar.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                Intent it = new Intent(TelaRecuperarSenhaNumero.this,
                        TelaRecuperarSenhaEmail.class);
                startActivity(it);
            }
        });

        // 4) evento do txt recuperar com email
        lblRecupEmail.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                Intent it = new Intent(TelaRecuperarSenhaNumero.this,
                        TelaRecuperarSenhaEmail.class);
                startActivity(it);
            }
        });
    }
}