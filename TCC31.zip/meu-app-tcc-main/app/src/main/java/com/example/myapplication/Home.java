package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;

public class Home extends AppCompatActivity
{
    TextView lblNomeUsuario;
    Button btnLogout;

    FirebaseAuth mAuth;
    FirebaseFirestore db;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        //Linkando elementos
        btnLogout = findViewById(R.id.btnLogout);
        lblNomeUsuario = findViewById(R.id.lblNomeUsuario);
        mAuth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();

        //Busca nome do usuário para a mensagem de Bem Vindo
        buscarNomeUsuario();

        btnLogout.setOnClickListener(v ->
        {
            FirebaseAuth.getInstance().signOut();

            startActivity(new Intent(Home.this, TelaLogin.class));
            finish();
        });
    }

    private void buscarNomeUsuario()
    {
        if (mAuth.getCurrentUser() == null)
        {
            Toast.makeText(this, "Usuário não está logado", Toast.LENGTH_SHORT).show();

            startActivity(new Intent(Home.this, TelaLogin.class));
            finish();
            return;
        }

        String uid = mAuth.getCurrentUser().getUid();

        db.collection("usuarios").document(uid).get()
                .addOnSuccessListener(document ->
                {
                    if (document.exists())
                    {
                        String nome = document.getString("nome");
                        lblNomeUsuario.setText(nome);
                    }
                    else
                    {
                        Toast.makeText(this, "Dados do usuário não encontrados", Toast.LENGTH_SHORT).show();
                    }
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(this, "Erro ao buscar usuário", Toast.LENGTH_SHORT).show();
                });
    }
}

